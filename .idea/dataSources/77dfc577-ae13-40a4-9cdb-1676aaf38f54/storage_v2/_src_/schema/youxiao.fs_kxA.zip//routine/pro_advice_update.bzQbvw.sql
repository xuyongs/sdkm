create
  definer = root@localhost procedure pro_advice_update(IN i bigint)
begin
	declare s varchar(2);
	select status into s from system_advice where  id=i;
	if s='0' then 
		set s='1';
	else 
		set s='0';
	end if;
	update system_advice set status=s where id=i;
end;

