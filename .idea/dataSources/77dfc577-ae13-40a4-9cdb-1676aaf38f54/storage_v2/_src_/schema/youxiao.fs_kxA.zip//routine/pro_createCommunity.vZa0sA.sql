create
  definer = root@localhost procedure pro_createCommunity(IN cName varchar(50), IN ct varchar(2), IN userId bigint,
                                                         OUT rs varchar(2))
begin
	declare i int default 0;
	declare cId bigint default 0;
	#成功
	set rs = 1;
	SELECT COUNT(*) into i FROM `app_community` WHERE communityName=cName;
	if i=0 then
		#添加圈子信息
		INSERT INTO `app_community` VALUES(NULL,cName,ct,userId);
		#查询出圈子的id
		SELECT id into cId FROM app_community WHERE communityName=cName;
		#插入圈子用户的关联关系
		INSERT INTO `app_user_community` VALUES(NULL,cId,userId);
	else
		#失败
		set rs=0;
	end if;
end;

