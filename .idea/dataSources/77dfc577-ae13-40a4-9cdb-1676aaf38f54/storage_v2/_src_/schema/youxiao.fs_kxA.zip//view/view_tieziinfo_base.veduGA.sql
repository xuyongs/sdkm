create view view_tieziinfo_base as (select `tz`.`id`                            AS `tieziId`,
                                           `tz`.`content`                       AS `content`,
                                           `tz`.`publishTime`                   AS `publishTime`,
                                           `au`.`uName`                         AS `uName`,
                                           `au`.`headIcon`                      AS `headIcon`,
                                           ifnull(`praise_temp`.`praiseNum`, 0) AS `praiseNum`,
                                           `au`.`id`                            AS `appUserId`,
                                           `ac`.`id`                            AS `communityId`,
                                           `ac`.`communityName`                 AS `communityName`
                                    from (((`youxiao`.`tiezi` `tz` join `youxiao`.`app_users` `au` on ((`tz`.`appUserId` = `au`.`id`))) join `youxiao`.`app_community` `ac` on ((`ac`.`id` = `tz`.`communityId`)))
                                           left join (select count(0)                         AS `praiseNum`,
                                                             `youxiao`.`app_praise`.`tieziId` AS `tieziId`
                                                      from `youxiao`.`app_praise`
                                                      group by `youxiao`.`app_praise`.`tieziId`) `praise_temp`
                                                     on ((`tz`.`id` = `praise_temp`.`tieziId`)))
                                    where (`tz`.`status` = '1'));

