create
  definer = root@localhost procedure pro_insertMany(IN num int)
begin
	declare i int default 1;
	while i<=num do
		insert into `salary` values(null,ceil(RAND()*1000),concat('test',i),i);
		set i = i+1;
	end while;
end;

