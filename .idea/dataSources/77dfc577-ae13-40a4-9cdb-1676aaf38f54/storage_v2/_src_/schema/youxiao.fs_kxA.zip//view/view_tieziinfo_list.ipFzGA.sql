create view view_tieziinfo_list as (select `temp1`.`tieziId`             AS `tieziId`,
                                           `temp1`.`content`             AS `content`,
                                           `temp1`.`publishTime`         AS `publishTime`,
                                           `temp1`.`uName`               AS `uName`,
                                           `temp1`.`headIcon`            AS `headIcon`,
                                           `temp1`.`praiseNum`           AS `praiseNum`,
                                           `temp1`.`status`              AS `status`,
                                           `temp1`.`appUserId`           AS `appUserId`,
                                           `temp1`.`communityId`         AS `communityId`,
                                           `temp1`.`communityName`       AS `communityName`,
                                           ifnull(`temp2`.`url`, '没有图片') AS `url`
                                    from (((select `tz`.`id`                            AS `tieziId`,
                                                   `tz`.`content`                       AS `content`,
                                                   `tz`.`publishTime`                   AS `publishTime`,
                                                   `au`.`uName`                         AS `uName`,
                                                   `au`.`headIcon`                      AS `headIcon`,
                                                   ifnull(`praise_temp`.`praiseNum`, 0) AS `praiseNum`,
                                                   `tz`.`status`                        AS `status`,
                                                   `au`.`id`                            AS `appUserId`,
                                                   `ac`.`id`                            AS `communityId`,
                                                   `ac`.`communityName`                 AS `communityName`
                                            from (((`youxiao`.`tiezi` `tz` join `youxiao`.`app_users` `au` on ((`tz`.`appUserId` = `au`.`id`))) join `youxiao`.`app_community` `ac` on ((`ac`.`id` = `tz`.`communityId`)))
                                                   left join (select count(0)                         AS `praiseNum`,
                                                                     `youxiao`.`app_praise`.`tieziId` AS `tieziId`
                                                              from `youxiao`.`app_praise`
                                                              group by `youxiao`.`app_praise`.`tieziId`) `praise_temp`
                                                             on ((`tz`.`id` = `praise_temp`.`tieziId`))))) `temp1`
                                           left join `youxiao`.`app_images` `temp2`
                                                     on ((`temp1`.`tieziId` = `temp2`.`tieziId`)))
                                    where (`temp1`.`status` = '1'));

