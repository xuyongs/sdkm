create
  definer = root@localhost procedure pro_call(IN i int)
begin
	case i
		when 1 then
			select '拨打张三的号码' as 提示;
		WHEN 2 THEN	
			SELECT '拨打李四的号码' AS 提示;
		WHEN 3 THEN
			SELECT '拨打王五的号码' AS 提示;
		else
			select '拨打错误' AS 提示;
	end case;
end;

