create
  definer = root@localhost procedure pro_buycar(IN money float, OUT rs varchar(50))
begin
	if money>500 then
		set rs = '法拉第';
	elseif money>100 then
		set rs = '奥迪';
	elseif money>10 then
		set rs = '奥拓';
	else
		set rs = '11路公交';
	end if;
end;

