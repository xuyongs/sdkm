create
  definer = root@localhost procedure pro_sum(IN num int)
BEGIN
	
	DECLARE i INT DEFAULT 1;
	declare rs int default 0;
	aaa:loop
		set rs = rs+i;
		set i=i+1;
		
		#终止条件
		if i>num then
			leave aaa;
		end if;
	end loop;
	select rs as 结果;
END;

